#pragma once
#include "stdafx.h"
#include <opencv2\core\core.hpp>
#include <opencv2\highgui\highgui.hpp>
#include <opencv2\features2d\features2d.hpp>
#include <iostream>
#include <numeric>
#include <opencv2\imgproc\imgproc.hpp>

using namespace cv;
using namespace std;

#ifndef _CIRAFI_
#define _CIRAFI_

struct CIRAFIData
{
	string id;
	vector<Mat> templates;
	double CIFIdata[25][13];
	double RAFIdata[25][36][36];
};
struct CIRAFIBase
{
	int nScales;
	int nRadials;
	int nCircles;
	vector<int> circles[2][13];
	vector<int> radials[2][36];
};

int sub2ind(int, int, int);

namespace CIRAFI {
	CIRAFIBase Setup(void);
	CIRAFIData Scales(Mat*, CIRAFIBase*);
	CIRAFIData AssignID(CIRAFIData, string);
	CIRAFIData CIRAFI(Mat*, CIRAFIBase*);
}


//CIRAFIBase TemplatePrep(Mat, int, int);
#endif